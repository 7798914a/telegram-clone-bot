import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_USER_ID = int(os.getenv("ADMIN_USER_ID", "0"))

OKPAY_APP_ID = "37273"
OKPAY_TOKEN = "mqF8Dy5cCWEAApi2rLXaFo0kEvxUVlYV"
OKPAY_API_URL = "https://api.okaypay.me/shop"
OKPAY_CALLBACK_URL = None  # 启动时自动设置

REDIS_CONFIG = {
    "host": os.getenv("REDIS_HOST", "localhost"),
    "port": int(os.getenv("REDIS_PORT", "6379")),
    "db": int(os.getenv("REDIS_DB", "0")),
}

PG_CONFIG = {
    "host": os.getenv("PG_HOST", "localhost"),
    "port": int(os.getenv("PG_PORT", "5432")),
    "database": os.getenv("PG_DATABASE", "cloner"),
    "user": os.getenv("PG_USER", "cloner"),
    "password": os.getenv("PG_PASSWORD", ""),
}

COLLECTOR_DIR = os.path.dirname(os.path.abspath(__file__))
SESSION_DIR = os.path.join(COLLECTOR_DIR, "sessions")
os.makedirs(SESSION_DIR, exist_ok=True)